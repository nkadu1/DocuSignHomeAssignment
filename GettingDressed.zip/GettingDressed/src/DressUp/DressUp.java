package DressUp;
import java.util.ArrayList;
import java.util.List;

public class DressUp implements IDressUp {
	private IPutOns weather;
    private List<String> processedCommands;
    private String failure;
	private ProcessInputString process;
    private String input;
	
    public DressUp(String input) {
		// TODO Auto-generated constructor stub
        processedCommands = new ArrayList<String>();
        failure ="fail";
        this.input =  input;
        process = new ProcessInputString(input);
	}
	
	/*
	 * Function to process the input string 
	 */
	public String DressingOrder() throws Exception{
		
		String s[] = process.ProcessInput();
		s[0] = s[0].toUpperCase();
			//Initialize Object with type of weather
			if(s[0].equals("HOT")){
				weather =  new HotWeather();
			}
			else if(s[0].equals("COLD")){
				weather =  new ColdWeather();
			}
			else {
				throw new Exception("Invalid input, please enter valid weather value");
			}
			
            StringBuilder dressingOrder = new StringBuilder();
            //process string and store the dress up order in stringbuilder 
            try{
					for(int i=1;i<s.length;i++){
						String command = s[i];
	                    if (IsValid(command)){
	                    	switch (s[i])
	                        {
	                            case "1":
	                                dressingOrder.append(", ").append(weather.putFootWear());
	                                break;
	                            case "2":
	                                dressingOrder.append(", ").append(weather.putHeadWear());
	                                break;
	                            case "3":
	                                dressingOrder.append(", ").append(weather.putSocks());
	                                break;
	                            case "4":
	                                dressingOrder.append(", ").append(weather.putShirt());
	                                break;
	                            case "5":
	                                dressingOrder.append(", ").append(weather.putJacket());
	                                break;
	                            case "6":
	                                dressingOrder.append(", ").append(weather.putPants());
	                                break;
	                            case "7":
	                                dressingOrder.append(", ").append(weather.leaveHouse());
	                                break;
	                            case "8":
	                                dressingOrder.append(", ").append(weather.takeOffPajamas());
	                                break;
	                            default:
	                                throw new Exception("Invalid weather specified in the first arguement");
	                        }
	                    }
	                    processedCommands.add(command);
					}
			}
			catch(Exception ex){	
				if (ex.getMessage().equals(failure))
                {                    
                    return dressingOrder.append(", ").append(ex.getMessage()).toString().substring(2);
                    //Remove leading ", " before returning the value
                }

                //Else, throw it back and let the main method handle it
                else
                {
                    throw new Exception(ex);
                }
			}
			return (dressingOrder.toString()).substring(2);
					
	}
	
	/*
	 * Check if input command is valid
	 */
	private boolean IsValid(String command) throws Exception
    {
        
        if (processedCommands.size() == 0)
        {                
            if (!command.equals("8"))
            {
            	throw new Exception(failure);
            }
        }

        //Only 1 piece of each type of clothing may be put on
        if (processedCommands.contains(command))
        {
        	throw new Exception(failure);
        }

        //You cannot put on socks when it is hot
        //You cannot put on a jacket when it is hot
        if ((command == "3") || (command == "5"))     //If command is for putting on socks or jacket and dresser is of type HotDresser (it is hot)
        {
            if (weather instanceof HotWeather)
            {
            	throw new Exception(failure);
            }
        }

        //Socks must be put on before shoes
        //Pants must be put on before shoes
        //In other words, if the command is for shoes/footwear, make sure that socks and pants are already put on
        else if (command == "1")
        {
            //if the weather is hot check only for pants
        	if (weather instanceof HotWeather)
            {
                if (!processedCommands.contains("6"))
                {
                	throw new Exception(failure);
                }
            }                
            //else, check for both socks and pants
            else
            {
                if (!processedCommands.contains("3") || !processedCommands.contains("6"))
                {
                	throw new Exception(failure);
                }
            }
        }

        //The shirt must be put on before the headwear or jacket
        //In other words, if the command is for either the headwear or the jacket, make sure that the shirt is already put on
        else if ((command.equals("2")) || (command.equals("5")))
        {
            if (!processedCommands.contains("4"))
            {
            	throw new Exception(failure);
            }
        }

        //You cannot leave the house until all items of clothing are on (except socks and a jacket when it�s hot)
        //If the command is for leaving the house, make sure that all the other commands have been processed
        else if (command.equals("7"))
        {
            //Check if jacket and socks are put on only if the weather is hot
        	if (!(weather instanceof HotWeather))        //weather is not hot
            {
                if (!processedCommands.contains("3") || !processedCommands.contains("5"))       
                	//jacket or shoes/footwear not put on
                {
                	throw new Exception(failure);
                }
            }

            //Check for other types of clothing irrespective of the weather type
            if (!processedCommands.contains("1") || !processedCommands.contains("2") || !processedCommands.contains("4") || !processedCommands.contains("6") || !processedCommands.contains("8"))
            {
            	throw new Exception(failure);
            }
        }

        //If all the conditions are satisfied, return true
        return true;
    }

	
}
