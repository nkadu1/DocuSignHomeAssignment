package DressUp;

public interface IDressUp {
	public String DressingOrder() throws Exception;
	
}
