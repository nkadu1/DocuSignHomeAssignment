package DressUp;
/*
 * Interface to list to do activities for a weather
 */
public interface IPutOns {
	public String 	putFootWear();
	public String 	putHeadWear();
	public String 	putSocks();
	public String 	putShirt();
	public String 	putJacket();
	public String 	putPants();
	public String 	leaveHouse();
	public String 	takeOffPajamas();
}
